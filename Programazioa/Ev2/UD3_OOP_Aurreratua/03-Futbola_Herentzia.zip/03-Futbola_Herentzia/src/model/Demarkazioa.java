/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author arceredillo.adrian
 */
public enum Demarkazioa {
    /**
     * Este archivo de tipo numeración, se encargará de recoger las diferentes
     * posiciones que tendrán los "objetos"; en este caso, los objetos serán del 
     * tipo IntegranteSeleccion
     */
    POR, DEF, MED, DEL
}
